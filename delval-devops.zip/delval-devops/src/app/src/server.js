const express = require('express');
const app = express();
const port = process.env.PORT || 3001;

// Serve static files from public directory
// app.use(express.static('public'));

app.get('/health', (req, res) => {
  res.status(200).send('OK');
});

app.get('/', (req, res) => {
  res.status(200).send('Welcome to DELVAL app');
});

app.listen(port, () => {
  console.log(`DELVAL app listening on port ${port}`);
});
