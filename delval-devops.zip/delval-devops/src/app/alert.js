const nodemailer = require('nodemailer');

// Configure transporter for sending email alerts
const transporter = nodemailer.createTransport({
  host: 'smtp.example.com',
  port: 587,
  secure: false, // true for 465, false for other ports
  auth: {
    user: 'alertmanager@example.com',
    pass: 'yourpassword',
  },
});

// Function to send alert email
function sendAlert(subject, message) {
  const mailOptions = {
    from: '"DELVAL Alert" <alertmanager@example.com>',
    to: 'admin@example.com',
    subject: subject,
    text: message,
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      return console.error('Error sending alert email:', error);
    }
    console.log('Alert email sent:', info.response);
  });
}

// Example usage: send an alert
if (require.main === module) {
  sendAlert(
    'System Alert: High CPU Usage',
    'CPU usage has exceeded the threshold on the DELVAL app server.'
  );
}

module.exports = { sendAlert };
