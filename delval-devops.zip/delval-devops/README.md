# DELVAL LTD DevOps Project

## Overview
This project provides a complete containerized DevOps solution for the DELVAL LTD high-traffic platform. It includes a sample Node.js app, Docker containerization, Kubernetes orchestration, Jenkins CI/CD pipeline, Prometheus monitoring with Alertmanager, and optional Terraform infrastructure code.

## Directory Structure
```
delval-devops/
├── src/
│   └── app/                # Sample Node.js app
├── docker/
│   └── app/                # Dockerfile for app container
├── kubernetes/
│   ├── environments.yaml   # Kubernetes namespaces
│   └── prod/
│       ├── deployment.yaml # Production deployment config
│       └── hpa.yaml        # Horizontal Pod Autoscaler config
├── jenkins/
│   └── Jenkinsfile         # Jenkins CI/CD pipeline
├── monitoring/
│   ├── alertmanager-config.yaml # Alertmanager email config
│   └── alerts.yaml              # Prometheus alert rules
└── terraform/
    └── main.tf             # Optional Terraform infrastructure code
```

## Setup Instructions

### Prerequisites
- Docker
- Kubernetes cluster with kubectl configured
- Jenkins server with Docker and kubectl access
- Prometheus and Alertmanager installed in the cluster
- Terraform (optional)

### Build and Run Docker Image
```bash
cd delval-devops
docker build -t delval-app -f docker/app/Dockerfile .
docker run -p 3000:3000 delval-app
```

### Deploy to Kubernetes
```bash
kubectl apply -f kubernetes/environments.yaml
kubectl apply -f kubernetes/prod/deployment.yaml
kubectl apply -f kubernetes/prod/hpa.yaml
```

### Jenkins Pipeline
- Configure Jenkins with Docker and Kubernetes credentials
- Use the provided `jenkins/Jenkinsfile` for CI/CD pipeline
- Pipeline stages: Build, Test, Security Scan (Trivy), Deploy to prod on main branch

### Monitoring and Alerts
- Configure Prometheus to use `monitoring/alerts.yaml`
- Configure Alertmanager with `monitoring/alertmanager-config.yaml`
- Set environment variable `EMAIL_PASSWORD` for Alertmanager email auth

### Terraform (Optional)
- Customize `terraform/main.tf` for your infrastructure needs
- Run `terraform init` and `terraform apply` to provision resources

## Security Best Practices
- Dockerfile uses non-root user
- Kubernetes deployment has resource limits and probes
- Jenkins pipeline includes Trivy security scanning
- Secrets are managed via environment variables and not committed

## .gitignore
- node_modules/
- *.env
- secrets/

## Contact
For questions, contact admin@delval.com
